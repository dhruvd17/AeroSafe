let map;

// Initialize or update the map
function initializeMap(lat, lon) {
    if (!map) {
        map = L.map('map').setView([lat, lon], 7);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
        }).addTo(map);
    } else {
        map.setView([lat, lon], 7);
    }
}

// Custom red marker icon
const redMarkerIcon = L.icon({
    iconUrl: 'pngegg.png', // URL for the red marker icon
    iconSize: [25, 41], // Size of the icon
    iconAnchor: [12, 41], // Point of the icon which will correspond to marker's location
    popupAnchor: [1, -34], // Point from which the popup should open relative to the iconAnchor
});

// Main function to check route weather on specified date
async function checkRouteWeather() {
    const start = document.getElementById("start-city").value;
    const end = document.getElementById("end-city").value;
    const dateInput = document.getElementById("date-input").value;

    const selectedDate = new Date(dateInput);
    const currentDate = new Date();
    const maxForecastDate = new Date();
    maxForecastDate.setDate(currentDate.getDate() + 7);

    if (selectedDate > maxForecastDate) {
        document.getElementById("weather-info").innerText = "Forecast not available for dates beyond 7 days.";
        return;
    }

    try {
        const startCoords = await getCoordinates(start);
        const endCoords = await getCoordinates(end);

        if (!startCoords || !endCoords) {
            document.getElementById("weather-info").innerText = "Unable to fetch route information. Check city names.";
            return;
        }

        initializeMap(startCoords.lat, startCoords.lon);

        const alertRadius = 150; // km
        const intervalPoints = 10; // Increase for more points along route

        const severeWeatherAlert = await checkForSevereWeatherAlongRoute(startCoords, endCoords, alertRadius, intervalPoints, selectedDate);

        if (severeWeatherAlert) {
            document.getElementById("weather-info").innerHTML = `<p>Warning: Severe weather detected along the route on ${selectedDate.toDateString()}.</p>`;
        } else {
            document.getElementById("weather-info").innerHTML = `<p>Route is safe with no severe weather detected on ${selectedDate.toDateString()}.</p>`;
        }

        // Add marker for start city
        L.marker([startCoords.lat, startCoords.lon]).addTo(map).bindPopup(`${start}`).openPopup();
        
        // Add marker for the end city with a red icon
        L.marker([endCoords.lat, endCoords.lon], { icon: redMarkerIcon })
            .addTo(map)
            .bindPopup(`${end}`).openPopup();
        
        // Add weather details on the map
        await addWeatherDetails(startCoords.lat, startCoords.lon);
        // await addWeatherDetails(endCoords.lat, endCoords.lon);
        
    } catch (error) {
        document.getElementById("weather-info").innerText = "Error retrieving weather information.";
        console.error("Error checking route weather:", error);
    }
}

// Function to get city coordinates
async function getCoordinates(city) {
    const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=77baa1bc9266417b905e33d9084d4244`);
    const data = await response.json();
    if (data.cod === 200) {
        return { lat: data.coord.lat, lon: data.coord.lon };
    } else {
        console.error("City not found:", data.message);
        return null;
    }
}

// Add weather details such as cloud coverage and storms
async function addWeatherDetails(lat, lon) {
    const apiKey = '77baa1bc9266417b905e33d9084d4244';
    const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}`);
    const data = await response.json();

    const cloudCoverage = data.clouds.all; // Percentage of cloud coverage
    const weatherDescription = data.weather[0].description;

    // Display cloud coverage
    L.marker([lat, lon]).addTo(map)
        .bindPopup(`Cloud Coverage: ${cloudCoverage}%<br>Description: ${weatherDescription}`).openPopup();
}

// Check severe weather along route for a specific date
async function checkForSevereWeatherAlongRoute(start, end, radius, intervals, date) {
    let severeWeatherDetected = false;

    for (let i = 0; i <= intervals; i++) {
        const lat = start.lat + (i * (end.lat - start.lat)) / intervals;
        const lon = start.lon + (i * (end.lon - start.lon)) / intervals;

        // Fetch forecast weather data for each interval point
        const weatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=77baa1bc9266417b905e33d9084d4244`);
        const forecastData = await weatherResponse.json();

        // Filter forecasts to match the selected date
        const selectedDateForecasts = forecastData.list.filter(forecast => {
            const forecastDate = new Date(forecast.dt * 1000);
            return forecastDate.toDateString() === date.toDateString();
        });

        // Check for severe weather in the filtered forecasts
// Check for severe weather in the filtered forecasts
    selectedDateForecasts.forEach(forecast => {
    const cloudCoverage = forecast.clouds.all; // Get the cloud coverage for the forecast
    if (isSevereWeather(forecast.weather[0].description, cloudCoverage)) {
        severeWeatherDetected = true;

        // Log for debugging
        console.log(`Severe weather found at: ${lat}, ${lon} - ${forecast.weather[0].description}`);

        // Add marker for severe weather condition
        const marker = L.marker([lat, lon]).addTo(map);
        marker.bindPopup(`Severe Weather: ${forecast.weather[0].description}`).openPopup();
    }
});

    }
    return severeWeatherDetected;
}

// Function to identify severe weather conditions
function isSevereWeather(description, cloudCoverage) {
    const severeKeywords = ["tornado", "cyclone", "storm", "heavy rain", "hurricane", "flood", "severe thunderstorm", "blizzard", "extreme wind"];
    const isSevereCondition = severeKeywords.some(keyword => description.toLowerCase().includes(keyword));
    return isSevereCondition || cloudCoverage > 80; // Check cloud coverage
}

// Set the minimum date to today
document.addEventListener('DOMContentLoaded', () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
    const yyyy = today.getFullYear();

    const minDate = `${yyyy}-${mm}-${dd}`;
    document.getElementById('date-input').setAttribute('min', minDate);
});
