function toggleSearchBox() {
    const searchBox = document.getElementById('searchBox');
    if (searchBox.style.display === 'none') {
        searchBox.style.display = 'block'; // Show the search box
        searchBox.focus(); // Focus on the search box
    } else {
        searchBox.style.display = 'none'; // Hide the search box
    }
}
function toggleContactDialog() {
    const dialog = document.getElementById('contactDialog');
    const contactButton = document.querySelector('.contact-us');

    if (dialog.style.display === 'none') {
        // Display the dialog
        dialog.style.display = 'block';

        // Calculate the position based on button position
        const rect = contactButton.getBoundingClientRect();
        const dialogHeight = dialog.offsetHeight;

        // Position dialog box so left edge is aligned and vertically centered
        dialog.style.left = `${rect.left + contactButton.offsetWidth + 10}px`; // Slightly offset from button
        dialog.style.top = `${rect.top + rect.height / 2 - dialogHeight / 2}px`; // Center vertically with button
    } else {
        dialog.style.display = 'none';
    }
}

// Copy to Clipboard Function
function copyToClipboard(elementId) {
    const text = document.getElementById(elementId).textContent;
    navigator.clipboard.writeText(text).then(() => {
        alert('Copied to clipboard!');
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
}
